# HT03 — REGISTRO FOTOGRÁFICO PROFESIONAL

## Arquitectura

Navegador → IndexedDB → JavaScript → Node.js/Express → SQLite → DOCX

La aplicación mantiene una copia local mediante IndexedDB y un almacenamiento principal en SQLite.

## Instalación

```bash
npm install
```

## Ejecución

```bash
npm start
```

Abrir:

```text
http://localhost:3000
```

Desarrollo:

```bash
npm run dev
```

## Base SQLite

Se crea automáticamente:

```text
database/registro_fotografico.db
```

Las fotografías se guardan como BLOB en SQLite.

## IndexedDB

Base local del navegador:

```text
HT03RegistroFotografico
```

Object stores:

- proyectosLocal
- fotosLocal

Permite conservar una copia local para recuperar el trabajo después de recargar o volver a abrir la aplicación en el mismo navegador.

## Funciones

- Crear proyecto
- Editar proyecto
- Eliminar proyecto
- Capturar/seleccionar fotografía
- Vista previa
- Descripción obligatoria
- Guardar en SQLite
- Guardar copia en IndexedDB
- Galería
- Editar descripción
- Subir/bajar
- Eliminar con confirmación
- Separación por proyecto
- Exportación DOCX
- Diseño responsive

## Flujo recomendado para la demostración

1. Crear `PRACTICA 001`.
2. Registrar datos ficticios.
3. Agregar seis fotografías propias autorizadas.
4. Cambiar el orden.
5. Eliminar una.
6. Agregar otra.
7. Recargar el navegador.
8. Verificar que el proyecto continúa.
9. Crear `PRACTICA 002`.
10. Verificar que no aparecen fotos de `PRACTICA 001`.
11. Generar Word.
12. Abrir el DOCX y comprobar las imágenes.

## Celular

El campo de imagen utiliza:

```html
accept="image/*" capture="environment"
```

Para cámara real en celular, el navegador debe permitir el acceso al dispositivo. En desarrollo local, `localhost` es un contexto seguro; para acceder desde otro dispositivo normalmente se recomienda HTTPS.

## Importante para la sustentación

La consigna original solicita IndexedDB como persistencia mínima del navegador. Esta solución incorpora IndexedDB y SQLite, pero cumplen funciones distintas:

- IndexedDB: copia local del navegador.
- SQLite: persistencia del servidor/aplicación.
- DOCX: salida final del informe.

Las fotografías para la entrega deben ser propias, de objetos o espacios autorizados, y los datos deben ser ficticios.
