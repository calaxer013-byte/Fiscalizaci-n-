const path=require("path");
const Database=require("better-sqlite3");

const dbPath=path.join(__dirname,"registro_fotografico.db");
const db=new Database(dbPath);

db.pragma("foreign_keys = ON");
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS proyectos(
 id TEXT PRIMARY KEY,
 codigo TEXT NOT NULL UNIQUE,
 fecha TEXT NOT NULL,
 lugar TEXT NOT NULL,
 fiscalizador TEXT NOT NULL,
 establecimiento TEXT NOT NULL,
 creado_en TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 actualizado_en TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS fotos(
 id TEXT PRIMARY KEY,
 proyecto_id TEXT NOT NULL,
 nombre_archivo TEXT NOT NULL,
 mime_type TEXT NOT NULL,
 imagen BLOB NOT NULL,
 descripcion TEXT NOT NULL,
 fecha_hora TEXT NOT NULL,
 orden INTEGER NOT NULL,
 FOREIGN KEY(proyecto_id) REFERENCES proyectos(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_fotos_proyecto ON fotos(proyecto_id);
`);

function listarProyectos(){
 return db.prepare(`
 SELECT p.*,COUNT(f.id) total_fotos
 FROM proyectos p LEFT JOIN fotos f ON f.proyecto_id=p.id
 GROUP BY p.id ORDER BY p.creado_en DESC
 `).all();
}
function obtenerProyecto(id){return db.prepare("SELECT * FROM proyectos WHERE id=?").get(id);}
function crearProyecto(p){return db.prepare(`
 INSERT INTO proyectos(id,codigo,fecha,lugar,fiscalizador,establecimiento)
 VALUES(@id,@codigo,@fecha,@lugar,@fiscalizador,@establecimiento)
 `).run(p);}
function actualizarProyecto(id,p){return db.prepare(`
 UPDATE proyectos SET codigo=@codigo,fecha=@fecha,lugar=@lugar,
 fiscalizador=@fiscalizador,establecimiento=@establecimiento,
 actualizado_en=CURRENT_TIMESTAMP WHERE id=@id
 `).run({id,...p});}
function eliminarProyecto(id){return db.prepare("DELETE FROM proyectos WHERE id=?").run(id);}
function listarFotos(id){return db.prepare(`
 SELECT id,proyecto_id,nombre_archivo,mime_type,descripcion,fecha_hora,orden
 FROM fotos WHERE proyecto_id=? ORDER BY orden
 `).all(id);}
function listarFotosCompletas(id){return db.prepare("SELECT * FROM fotos WHERE proyecto_id=? ORDER BY orden").all(id);}
function obtenerImagen(id){return db.prepare("SELECT imagen,mime_type FROM fotos WHERE id=?").get(id);}
function agregarFoto(p){
 const max=db.prepare("SELECT COALESCE(MAX(orden),0) maximo FROM fotos WHERE proyecto_id=?").get(p.proyectoId).maximo;
 return db.prepare(`
 INSERT INTO fotos(id,proyecto_id,nombre_archivo,mime_type,imagen,descripcion,fecha_hora,orden)
 VALUES(@id,@proyectoId,@nombreArchivo,@mimeType,@imagen,@descripcion,@fechaHora,@orden)
 `).run({...p,orden:max+1});
}
function actualizarDescripcion(id,descripcion){return db.prepare("UPDATE fotos SET descripcion=? WHERE id=?").run(descripcion,id);}
function eliminarFoto(id){
 const f=db.prepare("SELECT proyecto_id,orden FROM fotos WHERE id=?").get(id);
 if(!f)return {changes:0};
 const r=db.prepare("DELETE FROM fotos WHERE id=?").run(id);
 db.prepare("UPDATE fotos SET orden=orden-1 WHERE proyecto_id=? AND orden>?").run(f.proyecto_id,f.orden);
 return r;
}
function moverFoto(id,direccion){
 const f=db.prepare("SELECT * FROM fotos WHERE id=?").get(id);
 if(!f)throw new Error("Fotografía no encontrada.");
 const total=db.prepare("SELECT COUNT(*) total FROM fotos WHERE proyecto_id=?").get(f.proyecto_id).total;
 const nuevo=direccion==="arriba"?f.orden-1:f.orden+1;
 if(nuevo<1||nuevo>total)return;
 const tx=db.transaction(()=>{
  db.prepare("UPDATE fotos SET orden=0 WHERE id=?").run(id);
  db.prepare("UPDATE fotos SET orden=? WHERE proyecto_id=? AND orden=?").run(f.orden,f.proyecto_id,nuevo);
  db.prepare("UPDATE fotos SET orden=? WHERE id=?").run(nuevo,id);
 });
 tx();
}
module.exports={db,dbPath,listarProyectos,obtenerProyecto,crearProyecto,actualizarProyecto,eliminarProyecto,listarFotos,listarFotosCompletas,obtenerImagen,agregarFoto,actualizarDescripcion,eliminarFoto,moverFoto};