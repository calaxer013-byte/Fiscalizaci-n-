const {
 Document,Packer,Paragraph,TextRun,Table,TableRow,TableCell,
 ImageRun,WidthType,AlignmentType,VerticalAlign
}=require("docx");

async function generarDOCX(proyecto,fotos){
 const children=[];

 children.push(new Paragraph({
  alignment:AlignmentType.CENTER,
  children:[new TextRun({text:"ANEXO 2 REGISTRO FOTOGRÁFICO",bold:true,size:20,font:"Arial"})]
 }));
 children.push(new Paragraph({
  alignment:AlignmentType.CENTER,
  spacing:{after:160},
  children:[new TextRun({text:`Código: ${proyecto.codigo}`,size:16,font:"Arial"})]
 }));

 const datos=[
  ["Fiscalizador",proyecto.fiscalizador],
  ["Lugar",proyecto.lugar],
  ["Establecimiento / Unidad",proyecto.establecimiento]
 ];
 children.push(new Table({
  width:{size:100,type:WidthType.PERCENTAGE},
  rows:datos.map(([a,b])=>new TableRow({children:[
   new TableCell({width:{size:28,type:WidthType.PERCENTAGE},shading:{fill:"17365D"},children:[
    new Paragraph({children:[new TextRun({text:a,bold:true,color:"FFFFFF",size:16,font:"Arial"})]})
   ]}),
   new TableCell({width:{size:72,type:WidthType.PERCENTAGE},children:[
    new Paragraph({children:[new TextRun({text:b,size:16,font:"Arial"})]})
   ]})
  ]}))
 }));

 children.push(new Paragraph({text:""}));
 children.push(new Paragraph({
  alignment:AlignmentType.CENTER,
  children:[new TextRun({text:`FOTOGRAFÍAS DE FECHA ${proyecto.fecha}`,bold:true,size:16,font:"Arial"})]
 }));
 children.push(new Paragraph({text:""}));

 for(let i=0;i<fotos.length;i++){
  const f=fotos[i];
  const numero=String(i+1).padStart(2,"0");
  const ext=f.mime_type==="image/png"?"png":"jpg";

  const imagen=new ImageRun({
   data:f.imagen,
   transformation:{width:470,height:260},
   type:ext
  });

  children.push(new Table({
   width:{size:100,type:WidthType.PERCENTAGE},
   rows:[
    new TableRow({cantSplit:true,children:[
     new TableCell({
      columnSpan:2,
      width:{size:100,type:WidthType.PERCENTAGE},
      verticalAlign:VerticalAlign.CENTER,
      children:[new Paragraph({alignment:AlignmentType.CENTER,children:[imagen]})]
     })
    ]}),
    new TableRow({cantSplit:true,children:[
     new TableCell({
      width:{size:18,type:WidthType.PERCENTAGE},
      children:[new Paragraph({alignment:AlignmentType.CENTER,children:[
       new TextRun({text:`Foto N.º ${numero}`,bold:true,size:16,font:"Arial"})
      ]})]
     }),
     new TableCell({
      width:{size:82,type:WidthType.PERCENTAGE},
      children:[new Paragraph({children:[
       new TextRun({text:f.descripcion,size:16,font:"Arial"})
      ]})]
     })
    ]})
   ]
  }));
  children.push(new Paragraph({text:""}));
  if((i+1)%2===0&&i!==fotos.length-1)
   children.push(new Paragraph({children:[new TextRun({break:1})]}));
 }

 const doc=new Document({
  creator:"SENATI - HT03",
  title:"Anexo 2 Registro Fotográfico",
  sections:[{
   properties:{page:{
    size:{width:11906,height:16838},
    margin:{top:1440,right:1440,bottom:1440,left:1440}
   }},
   children
  }]
 });
 return Packer.toBuffer(doc);
}
module.exports={generarDOCX};