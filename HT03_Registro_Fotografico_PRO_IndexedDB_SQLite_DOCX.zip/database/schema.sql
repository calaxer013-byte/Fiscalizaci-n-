CREATE TABLE proyectos(
 id TEXT PRIMARY KEY,
 codigo TEXT NOT NULL UNIQUE,
 fecha TEXT NOT NULL,
 lugar TEXT NOT NULL,
 fiscalizador TEXT NOT NULL,
 establecimiento TEXT NOT NULL,
 creado_en TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 actualizado_en TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE fotos(
 id TEXT PRIMARY KEY,
 proyecto_id TEXT NOT NULL,
 nombre_archivo TEXT NOT NULL,
 mime_type TEXT NOT NULL,
 imagen BLOB NOT NULL,
 descripcion TEXT NOT NULL,
 fecha_hora TEXT NOT NULL,
 orden INTEGER NOT NULL,
 FOREIGN KEY(proyecto_id) REFERENCES proyectos(id) ON DELETE CASCADE
);