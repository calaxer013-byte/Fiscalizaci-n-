let proyectoActivo=null;
let fotosActuales=[];
let dbLocal=null;

const $=id=>document.getElementById(id);

document.addEventListener("DOMContentLoaded",async()=>{
 await iniciarIndexedDB();
 await cargarProyectos();
 $("btnNuevoProyecto").onclick=()=>abrirModal();
 $("formProyecto").onsubmit=guardarProyecto;
 $("formFoto").onsubmit=guardarFoto;
 $("imagen").onchange=mostrarPreview;
 $("btnEditarProyecto").onclick=()=>proyectoActivo&&abrirModal(proyectoActivo);
 $("btnEliminarProyecto").onclick=eliminarProyectoActivo;
 $("btnExportar").onclick=exportarWord;
 $("btnSincronizar").onclick=sincronizarProyectoActivo;
 $("btnImportarLocal").onclick=recuperarLocal;
 $("btnGuardarLocal").onclick=guardarFotoLocal;
});

function alerta(msg,tipo="ok"){
 const b=document.createElement("div");b.className=`alert ${tipo}`;b.textContent=msg;
 $("alertas").appendChild(b);setTimeout(()=>b.remove(),4000);
}

async function api(url,options={}){
 const r=await fetch(url,options);
 const d=await r.json().catch(()=>({success:false,message:"Respuesta inválida."}));
 if(!r.ok||!d.success)throw new Error(d.message||"Error");
 return d;
}

/* ---------------- INDEXEDDB ---------------- */
function iniciarIndexedDB(){
 return new Promise((resolve,reject)=>{
  const request=indexedDB.open("HT03RegistroFotografico",1);
  request.onupgradeneeded=e=>{
   const db=e.target.result;
   if(!db.objectStoreNames.contains("proyectosLocal"))
    db.createObjectStore("proyectosLocal",{keyPath:"id"});
   if(!db.objectStoreNames.contains("fotosLocal")){
    const store=db.createObjectStore("fotosLocal",{keyPath:"id"});
    store.createIndex("proyectoId","proyectoId",{unique:false});
   }
  };
  request.onsuccess=e=>{dbLocal=e.target.result;resolve();};
  request.onerror=()=>reject(new Error("No fue posible iniciar IndexedDB."));
 });
}

function localPut(storeName,data){
 return new Promise((resolve,reject)=>{
  const tx=dbLocal.transaction(storeName,"readwrite");
  tx.objectStore(storeName).put(data);
  tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);
 });
}
function localGet(storeName,key){
 return new Promise((resolve,reject)=>{
  const tx=dbLocal.transaction(storeName,"readonly");
  const r=tx.objectStore(storeName).get(key);
  r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);
 });
}
function localGetAll(storeName){
 return new Promise((resolve,reject)=>{
  const tx=dbLocal.transaction(storeName,"readonly");
  const r=tx.objectStore(storeName).getAll();
  r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);
 });
}
function localDelete(storeName,key){
 return new Promise((resolve,reject)=>{
  const tx=dbLocal.transaction(storeName,"readwrite");
  tx.objectStore(storeName).delete(key);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);
 });
}

async function guardarProyectoLocal(p){
 await localPut("proyectosLocal",{...p,guardadoLocal:new Date().toISOString()});
}
async function guardarFotosLocales(p,fotos){
 for(const f of fotos){
  const existente=await localGet("fotosLocal",f.id);
  await localPut("fotosLocal",{...f,proyectoId:p.id,blob:existente?.blob||null});
 }
}

/* ---------------- PROYECTOS ---------------- */
async function cargarProyectos(){
 try{
  const d=await api("/api/proyectos");
  renderProyectos(d.proyectos);
 }catch(e){alerta(e.message,"error");}
}

function renderProyectos(list){
 const c=$("listaProyectos");
 if(!list.length){
  c.innerHTML=`<div class="empty" style="grid-column:1/-1"><strong>No hay proyectos registrados.</strong><br>Crea el primero para comenzar.</div>`;
  return;
 }
 c.innerHTML=list.map(p=>`
 <article class="project">
  <div class="code">${esc(p.codigo)}</div>
  <div class="meta">📅 ${esc(p.fecha)}<br>📍 ${esc(p.lugar)}<br>👤 ${esc(p.fiscalizador)}<br>📷 ${p.total_fotos} fotografía(s)</div>
  <button class="btn btn-primary" onclick="abrirProyecto('${p.id}')">Abrir proyecto</button>
 </article>`).join("");
}

async function abrirProyecto(id){
 try{
  const d=await api(`/api/proyectos/${id}`);
  proyectoActivo=d.proyecto;fotosActuales=d.fotos;
  await guardarProyectoLocal(d.proyecto);
  await guardarFotosLocales(d.proyecto,d.fotos);
  $("panelTrabajo").classList.remove("hidden");
  renderProyecto(d.proyecto,d.fotos);
  window.scrollTo({top:$("panelTrabajo").offsetTop-15,behavior:"smooth"});
 }catch(e){alerta(e.message,"error");}
}

function renderProyecto(p,fotos){
 $("tituloProyecto").textContent=p.codigo;
 $("resumenProyecto").textContent=`${p.fecha} · ${p.lugar} · ${p.fiscalizador} · ${p.establecimiento}`;
 $("statFotos").textContent=fotos.length;
 const porcentaje=fotos.length?Math.round(fotos.filter(f=>f.descripcion?.trim()).length/fotos.length*100):0;
 $("statDescripcion").textContent=`${porcentaje}%`;
 $("statPersistencia").textContent="SQLite + IndexedDB";
 $("galeria").innerHTML=fotos.length?fotos.map((f,i)=>`
 <article class="photo-card">
  <div class="photo-image"><img src="/api/fotos/${f.id}/imagen" alt="Foto ${i+1}"></div>
  <div class="photo-body">
   <div class="photo-top"><span class="number">FOTO N.º ${String(i+1).padStart(2,"0")}</span><span class="date">${fecha(f.fecha_hora)}</span></div>
   <div class="description">${esc(f.descripcion)}</div>
   <div class="photo-actions">
    <button onclick="moverFoto('${f.id}','arriba')">↑ Subir</button>
    <button onclick="moverFoto('${f.id}','abajo')">↓ Bajar</button>
    <button onclick="editarDescripcion('${f.id}','${encodeURIComponent(f.descripcion)}')">✎ Editar</button>
    <button class="delete" onclick="eliminarFoto('${f.id}')">Eliminar</button>
   </div>
  </div>
 </article>`).join(""):`<div class="empty" style="grid-column:1/-1">No hay fotografías todavía.</div>`;
}

/* ---------------- FORMULARIO ---------------- */
function abrirModal(p=null){
 $("modalProyecto").classList.remove("hidden");$("formProyecto").reset();
 $("proyectoId").value=p?.id||"";$("modalTitulo").textContent=p?"Editar proyecto":"Nuevo proyecto";
 if(p){$("codigo").value=p.codigo;$("fecha").value=p.fecha;$("lugar").value=p.lugar;$("fiscalizador").value=p.fiscalizador;$("establecimiento").value=p.establecimiento;}
 else $("fecha").value=new Date().toISOString().slice(0,10);
}
function cerrarModal(){$("modalProyecto").classList.add("hidden");}

async function guardarProyecto(e){
 e.preventDefault();
 const id=$("proyectoId").value;
 const body={codigo:$("codigo").value,fecha:$("fecha").value,lugar:$("lugar").value,fiscalizador:$("fiscalizador").value,establecimiento:$("establecimiento").value};
 try{
  if(id){
   await api(`/api/proyectos/${id}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
   await abrirProyecto(id);
  }else{
   const d=await api("/api/proyectos",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
   await abrirProyecto(d.id);
  }
  cerrarModal();await cargarProyectos();alerta("Datos guardados correctamente.");
 }catch(e){alerta(e.message,"error");}
}

function mostrarPreview(){
 const file=$("imagen").files[0];
 if(!file){$("preview").textContent="Vista previa";return;}
 if(!file.type.startsWith("image/"))return alerta("El archivo no es una imagen.","error");
 const url=URL.createObjectURL(file);
 $("preview").innerHTML=`<img src="${url}" alt="Vista previa">`;
}

async function guardarFoto(e){
 e.preventDefault();
 if(!proyectoActivo)return alerta("Seleccione un proyecto.","error");
 const file=$("imagen").files[0],descripcion=$("descripcion").value.trim();
 if(!file)return alerta("Seleccione o tome una fotografía.","error");
 if(!descripcion)return alerta("La descripción es obligatoria.","error");
 if(file.size>10*1024*1024)return alerta("La imagen supera los 10 MB.","error");

 const fd=new FormData();fd.append("imagen",file);fd.append("descripcion",descripcion);
 try{
  await api(`/api/proyectos/${proyectoActivo.id}/fotos`,{method:"POST",body:fd});
  await abrirProyecto(proyectoActivo.id);await cargarProyectos();
  $("formFoto").reset();$("preview").textContent="Vista previa";
  alerta("Fotografía guardada en SQLite y sincronizada con IndexedDB.");
 }catch(e){alerta(e.message,"error");}
}

/* ---------------- FOTO LOCAL ---------------- */
async function guardarFotoLocal(){
 if(!proyectoActivo)return alerta("Seleccione un proyecto.","error");
 const file=$("imagen").files[0],descripcion=$("descripcion").value.trim();
 if(!file||!descripcion)return alerta("Seleccione una imagen y escriba una descripción.","error");
 const id=crypto.randomUUID();
 const foto={id,proyectoId:proyectoActivo.id,nombre_archivo:file.name,mime_type:file.type,descripcion,fecha_hora:new Date().toISOString(),orden:fotosActuales.length+1,blob:file};
 await localPut("fotosLocal",foto);
 alerta("Copia local guardada en IndexedDB.");
}

async function recuperarLocal(){
 try{
  const proyectos=await localGetAll("proyectosLocal");
  if(!proyectos.length)return alerta("No existen copias locales.","error");
  const p=proyectos.sort((a,b)=>new Date(b.guardadoLocal)-new Date(a.guardadoLocal))[0];
  proyectoActivo=p;
  const fotos=(await localGetAll("fotosLocal")).filter(f=>f.proyectoId===p.id);
  fotosActuales=fotos.sort((a,b)=>a.orden-b.orden);
  $("panelTrabajo").classList.remove("hidden");
  renderProyectoLocal(p,fotosActuales);
  alerta("Trabajo local recuperado desde IndexedDB.");
 }catch(e){alerta(e.message,"error");}
}

function renderProyectoLocal(p,fotos){
 $("tituloProyecto").textContent=p.codigo+" · COPIA LOCAL";
 $("resumenProyecto").textContent=`${p.fecha} · ${p.lugar} · ${p.fiscalizador}`;
 $("statFotos").textContent=fotos.length;
 $("statDescripcion").textContent=fotos.length?Math.round(fotos.filter(x=>x.descripcion?.trim()).length/fotos.length*100)+"%":"0%";
 $("statPersistencia").textContent="IndexedDB";
 $("galeria").innerHTML=fotos.length?fotos.map((f,i)=>{
  const src=f.blob?URL.createObjectURL(f.blob):"";
  return `<article class="photo-card"><div class="photo-image">${src?`<img src="${src}" alt="Foto local">`:"Sin imagen"}</div><div class="photo-body"><div class="photo-top"><span class="number">FOTO N.º ${String(i+1).padStart(2,"0")}</span><span class="date">${fecha(f.fecha_hora)}</span></div><div class="description">${esc(f.descripcion)}</div><div class="photo-actions"><button disabled>↑ Subir</button><button disabled>↓ Bajar</button><button disabled>✎ Editar</button><button class="delete" onclick="localDeleteFoto('${f.id}')">Eliminar</button></div></div></article>`;
 }).join(""):`<div class="empty">No hay fotografías locales.</div>`;
}

async function localDeleteFoto(id){
 if(!confirm("¿Eliminar la copia local?"))return;
 await localDelete("fotosLocal",id);await recuperarLocal();alerta("Copia local eliminada.");
}

/* ---------------- EDICIÓN / ORDEN ---------------- */
async function editarDescripcion(id,enc){
 const nueva=prompt("Nueva descripción:",decodeURIComponent(enc));
 if(nueva===null)return;
 try{
  await api(`/api/fotos/${id}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({descripcion:nueva.trim()})});
  await abrirProyecto(proyectoActivo.id);alerta("Descripción actualizada.");
 }catch(e){alerta(e.message,"error");}
}
async function moverFoto(id,direccion){
 try{
  await api(`/api/fotos/${id}/mover`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({direccion})});
  await abrirProyecto(proyectoActivo.id);
 }catch(e){alerta(e.message,"error");}
}
async function eliminarFoto(id){
 if(!confirm("¿Confirmas eliminar esta fotografía?"))return;
 try{
  await api(`/api/fotos/${id}`,{method:"DELETE"});
  await abrirProyecto(proyectoActivo.id);await cargarProyectos();alerta("Fotografía eliminada.");
 }catch(e){alerta(e.message,"error");}
}
async function eliminarProyectoActivo(){
 if(!proyectoActivo||!confirm(`¿Eliminar ${proyectoActivo.codigo} y sus fotografías?`))return;
 try{
  await api(`/api/proyectos/${proyectoActivo.id}`,{method:"DELETE"});
  proyectoActivo=null;$("panelTrabajo").classList.add("hidden");await cargarProyectos();alerta("Proyecto eliminado.");
 }catch(e){alerta(e.message,"error");}
}

/* ---------------- EXPORTACIÓN ---------------- */
async function exportarWord(){
 if(!proyectoActivo)return alerta("No hay proyecto activo.","error");
 try{
  const r=await fetch(`/api/proyectos/${proyectoActivo.id}/exportar`);
  if(!r.ok){const d=await r.json();throw new Error(d.message);}
  const blob=await r.blob(),url=URL.createObjectURL(blob),a=document.createElement("a");
  a.href=url;a.download=`Anexo_Fotografico_${proyectoActivo.codigo.replace(/[^a-z0-9_-]/gi,"_")}.docx`;
  document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);
  alerta("Documento Word generado correctamente.");
 }catch(e){alerta(e.message,"error");}
}

/* ---------------- SINCRONIZACIÓN ---------------- */
async function sincronizarProyectoActivo(){
 if(!proyectoActivo)return alerta("Seleccione un proyecto.","error");
 try{
  await guardarProyectoLocal(proyectoActivo);
  await guardarFotosLocales(proyectoActivo,fotosActuales);
  alerta("Proyecto sincronizado con IndexedDB.");
 }catch(e){alerta(e.message,"error");}
}

function fecha(v){return new Date(v).toLocaleString("es-PE",{dateStyle:"short",timeStyle:"short"});}
function esc(v){return String(v??"").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;");}