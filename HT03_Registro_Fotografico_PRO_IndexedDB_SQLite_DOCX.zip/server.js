const express = require("express");
const path = require("path");
const multer = require("multer");
const { randomUUID } = require("crypto");
const db = require("./database/db");
const { generarDOCX } = require("./database/exportador");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (!file.mimetype.startsWith("image/")) return cb(new Error("Solo se permiten imágenes."));
    cb(null, true);
  }
});

function ok(res, data={}) { res.json({ success:true, ...data }); }
function fail(res, message, status=400) { res.status(status).json({ success:false, message }); }

app.get("/api/health", (req,res) => {
  ok(res, { app:"HT03 Registro Fotográfico", database:"SQLite", status:"online" });
});

app.get("/api/proyectos", (req,res) => {
  try { ok(res,{proyectos:db.listarProyectos()}); }
  catch(e){ fail(res,e.message,500); }
});

app.get("/api/proyectos/:id", (req,res) => {
  try {
    const proyecto=db.obtenerProyecto(req.params.id);
    if(!proyecto) return fail(res,"Proyecto no encontrado.",404);
    ok(res,{proyecto,fotos:db.listarFotos(req.params.id)});
  } catch(e){ fail(res,e.message,500); }
});

app.post("/api/proyectos", (req,res) => {
  try {
    const {codigo,fecha,lugar,fiscalizador,establecimiento}=req.body;
    if(!codigo||!fecha||!lugar||!fiscalizador||!establecimiento)
      return fail(res,"Complete todos los datos obligatorios.");
    const id=randomUUID();
    db.crearProyecto({id,codigo:codigo.trim(),fecha,lugar:lugar.trim(),fiscalizador:fiscalizador.trim(),establecimiento:establecimiento.trim()});
    ok(res,{id,message:"Proyecto creado correctamente."});
  } catch(e) {
    fail(res,e.message.includes("UNIQUE")?"El código de práctica ya existe.":e.message);
  }
});

app.put("/api/proyectos/:id",(req,res)=>{
  try{
    const {codigo,fecha,lugar,fiscalizador,establecimiento}=req.body;
    if(!codigo||!fecha||!lugar||!fiscalizador||!establecimiento)
      return fail(res,"Complete todos los datos obligatorios.");
    const r=db.actualizarProyecto(req.params.id,{codigo:codigo.trim(),fecha,lugar:lugar.trim(),fiscalizador:fiscalizador.trim(),establecimiento:establecimiento.trim()});
    if(!r.changes)return fail(res,"Proyecto no encontrado.",404);
    ok(res,{message:"Proyecto actualizado."});
  }catch(e){fail(res,e.message);}
});

app.delete("/api/proyectos/:id",(req,res)=>{
  try{
    const r=db.eliminarProyecto(req.params.id);
    if(!r.changes)return fail(res,"Proyecto no encontrado.",404);
    ok(res,{message:"Proyecto eliminado."});
  }catch(e){fail(res,e.message,500);}
});

app.post("/api/proyectos/:id/fotos",upload.single("imagen"),(req,res)=>{
  try{
    if(!req.file)return fail(res,"Seleccione una fotografía.");
    if(!db.obtenerProyecto(req.params.id))return fail(res,"Proyecto no encontrado.",404);
    const descripcion=(req.body.descripcion||"").trim();
    if(!descripcion)return fail(res,"La descripción es obligatoria.");
    const id=randomUUID();
    db.agregarFoto({
      id, proyectoId:req.params.id,
      nombreArchivo:req.file.originalname,
      mimeType:req.file.mimetype,
      imagen:req.file.buffer,
      descripcion,
      fechaHora:new Date().toISOString()
    });
    ok(res,{id,message:"Fotografía guardada en SQLite."});
  }catch(e){fail(res,e.message,500);}
});

app.put("/api/fotos/:id",(req,res)=>{
  try{
    const descripcion=(req.body.descripcion||"").trim();
    if(!descripcion)return fail(res,"La descripción no puede estar vacía.");
    const r=db.actualizarDescripcion(req.params.id,descripcion);
    if(!r.changes)return fail(res,"Fotografía no encontrada.",404);
    ok(res,{message:"Descripción actualizada."});
  }catch(e){fail(res,e.message,500);}
});

app.delete("/api/fotos/:id",(req,res)=>{
  try{
    const r=db.eliminarFoto(req.params.id);
    if(!r.changes)return fail(res,"Fotografía no encontrada.",404);
    ok(res,{message:"Fotografía eliminada."});
  }catch(e){fail(res,e.message,500);}
});

app.post("/api/fotos/:id/mover",(req,res)=>{
  try{
    if(!["arriba","abajo"].includes(req.body.direccion))return fail(res,"Movimiento no válido.");
    db.moverFoto(req.params.id,req.body.direccion);
    ok(res,{message:"Orden actualizado."});
  }catch(e){fail(res,e.message,500);}
});

app.get("/api/fotos/:id/imagen",(req,res)=>{
  try{
    const f=db.obtenerImagen(req.params.id);
    if(!f)return res.status(404).end();
    res.set("Content-Type",f.mime_type);
    res.set("Cache-Control","no-store");
    res.send(f.imagen);
  }catch(e){res.status(500).end();}
});

app.get("/api/proyectos/:id/exportar",async(req,res)=>{
  try{
    const p=db.obtenerProyecto(req.params.id);
    if(!p)return fail(res,"Proyecto no encontrado.",404);
    const fotos=db.listarFotosCompletas(req.params.id);
    if(fotos.length<1)return fail(res,"Debe registrar al menos una fotografía.");
    const faltante=fotos.find(f=>!f.descripcion.trim());
    if(faltante)return fail(res,`La foto ${faltante.orden} no tiene descripción.`);
    const buffer=await generarDOCX(p,fotos);
    const nombre=`Anexo_Fotografico_${p.codigo.replace(/[^a-z0-9_-]/gi,"_")}.docx`;
    res.set({
      "Content-Type":"application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "Content-Disposition":`attachment; filename="${nombre}"`,
      "Content-Length":buffer.length
    });
    res.send(buffer);
  }catch(e){console.error(e);fail(res,"No se pudo generar el Word.",500);}
});

app.use((err,req,res,next)=>{
  console.error(err);
  fail(res,err.message||"Error interno.",500);
});

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));

app.listen(PORT,()=>{
  console.log("\n==============================================");
  console.log(" HT03 REGISTRO FOTOGRÁFICO PROFESIONAL");
  console.log("==============================================");
  console.log(` Servidor : http://localhost:${PORT}`);
  console.log(" SQLite   : ACTIVO");
  console.log(" IndexedDB: ACTIVO EN EL NAVEGADOR");
  console.log(" DOCX     : ACTIVO");
  console.log("==============================================\n");
});